#ifndef _LIBHEADERS_H_
#define _LIBHEADERS_H_
#define _CRT_SECURE_NO_WARNINGS
#define GLDEBUG
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#endif