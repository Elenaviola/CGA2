#include <stdio.h>
#include <stdlib.h>
#include "Game.h"

using namespace std;


int main(void)
{
	Game mg;
	mg.run();	
}