#ifndef _MAIN_GAME_
#define _MAIN_GAME_
#include "GameWindow.h"
#include "Input.h"
#include "glerror.h"
#include "libheaders.h"
#include "OBJLoader.h"

class Game : public GameWindow
{
public:
	Game::Game();
	~Game();

	void init() override;
	void shutdown() override;

	void update(GLdouble time) override;
	void render(GLdouble time) override;

	void onKey(Key key, Action action, Modifier modifier) override;
	void onMouseMove(MousePosition mouseposition) override;
	void onMouseButton(MouseButton button, Action action, Modifier modifier) override;
	void onMouseScroll(double xscroll, double yscroll) override;

	void onFrameBufferResize(int width, int height) override;

private:
};

#endif